<?php
    $template_dir = base_url().'../'.$template['temp_path'];
    //禁止修改input元素值
    $status = empty($activity['status'])?0:$activity['status'];
    function input_disabled($status){
        if($status >= 2) echo "disabled style='background-color:#eee;'";
    }
    // 隐藏元素
    function ele_display_none($status){
        if($status >= 2) echo "style='display:none;'";
    }
?>
<base href="<?php echo base_url().'suites/themes/default/';?>">
<link rel="stylesheet" type="text/css" href="<?php echo $template_dir;?>libs/css/common.css"/>
<link rel="stylesheet" type="text/css" href="js/bootstrap/dist/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="<?php echo $template_dir;?>libs/css/edit_template.css">
<link rel="stylesheet" href="fonts/font-awesome-4/css/font-awesome.min.css">
<style>
    .form-group{width:100%;}
    .red{color:red;}
    .activity-nav{height:30px}
    .activity-nav>li{width:118px;height:30px;line-height:30px;border:1px solid #ddd;}
    .activity-nav>.cur{background:#ddd}
    .activity-reward-set input[name='mode']{
        margin:-2px 2px 0px 10px;
    }
    .item-tbody input{
        width:100%;
        border:1px solid #ccc;
    }
    .item-tbody select{
        width:100%;
    }
    .activity-reward-set>.table tr>td{
      width:15px
    }
    .control-label,label{font-weight:normal;}

    /*文字颜色*/
    .set_text_color {float: left;margin-left: 10px;color: #414141;}

    /*切换活动设置按钮*/
    .go_activity_set {float: right;background: #2494F2;border-radius: 5px;color: #fff;font-size: 13px;padding: 2px 6px;margin-right: 10px;cursor: pointer;width: 90px;}
    /*编辑时的大转盘背景图片大小*/
    .activity_page .img1 {height: 330px!important;}
    /*背景开关*/
    em {font-style: normal;}
    .login-mima-icon {width: 75px;height: 28px;background: #fff;}
    .checkbtn {position: relative;display: block;width: 75px;height: 28px;background: #e3e3e3;border-radius: 15px;line-height: 32px;}
    .b-text {float: left;font-size: 13px;color: #fff;margin-left: 9px;line-height: 30px;display: none;}
    .b-pwd {float: right;font-size: 13px;color: #333333;margin-right: 14px;line-height: 30px;}
    .text-bg {display: block;position: absolute;top: 2px;left: 3px;width: 25px;height: 25px;border-radius: 50%;background: #fff;cursor: pointer;}
    .pwd-bg {display: none;position: absolute;top: 2px;right: 3px;width: 25px;height: 25px;border-radius: 50%;background: #fff;cursor: pointer;}
    /*对接设置*/
    input[type="radio"], input[type="checkbox"] {
        margin: -2px 0 0;
        line-height: normal;
    }
    input{text-align: center;}
    .joint dl{
        margin:0px;
    }
    .joint dd, .joint dt{
        /*margin:0px;
        padding:0px;*/
        display:inline-block;
        font-weight: normal;
    }
    .joint dt{
        margin-left: 35px;
    }
    .joint dd{
        margin: 5px 10px;
    }
    .joint dd span{
        font-weight: normal;
    }
    .joint input[type='text'] {
        border:1px solid #ccc!important;
        width:280px;
        height:34px;
        border-radius: 4px;
    }
    .time-input{display:inline-block;width:65%;}

    .special_text{padding: 5px 0px 0px 15px;}
    .operateBtn{margin-left: 40%;}
    .change_bg_btn{margin-top: 5px;}
    @media screen and (max-width:767px){
        .activity-content-set .form-group{margin: 0px 0px 15px;}
        .col-sm-6{width: 44%;}
        .col-sm-3{width: 30%;}
        .form-control{margin-top: 5px;}
        .col-sm-5{width: 41.66666667%;}
        .col-sm-2{width: 16.66666664%;margin-top: 5px;}
        .operateBtn{margin-left: 15%;}
    }
    @media screen and (max-width: 950px){
        .go_activity_set{float: none;}
    }
    .hlife_set{margin:10px 0;}
    .divider{border-top:1px solid #ccc;}
</style>

<div class="wl-container">
<!-- 活动模板开始 -->
    <div id="activity_template">

    </div>  <!-- 活动模板结束 -->
    <input type="hidden" value="<?php echo $template_dir;?>" class="template-dir"/>
    <!-- 模板设置开始 -->
    <div class="setting">
        <!-- 活动设置区域 -->
            <div class="activity-set" style="padding:10px;">
            <ul class="activity-nav">
              <li style="display:block;text-align:center;float:left;border-right: 0;" idx="1" class="cur">内容设置</li>
              <li style="display:block;text-align:center;float:left;border-right: 0;" idx="2">奖品设置</li>
              <li style="display:block;text-align:center;float:left;" idx="3">对接设置</li>
            </ul>

                <!-- 活动内容设置 -->
                <form class="form-horizontal" role="form" id="form-content">
                    <div class="activity-content-set">
                        <input type="hidden" name="status" class="status" value="<?php echo empty($activity['status'])?0:$activity['status'];?>">
                        <input type="hidden" name="flag" class="flag" value="1">
                        <input type="hidden" class="template_id" name="template_id" value="<?php echo empty($template['id']) ? 0 : $template['id'];?>">
                        <input type="hidden" name="id" class="activity_id" value="<?php echo empty($activity['id']) ? 0 : $activity['id'];?>">
                        <input type="hidden" value="" name="template_content" id="template_content">
                        <div class="form-group">
                            <label for="firstname" class="col-sm-2 control-label"><span class="red">*</span>活动名称</label>
                            <div class="col-sm-6">
                                <input type="text" class="form-control activity_name" name="activity_name" <?php input_disabled($status);?>
                                    value="<?php echo !isset($activity['activity_name']) ? "" : $activity['activity_name']; ?>"placeholder="">
                            </div>
                            <span class="name_info"></span>
                        </div>
                        <div class="form-group">
                            <label for="lastname" class="col-sm-2 control-label"><span class="red">*</span>活动时间</label>
                            <div class="col-sm-6">
                                <div>
                                    <span class="pull-left  time-title">起始时间：</span>
                                    <input class="form-control time-input" readonly onclick="laydate({istime: true, format: 'YYYY-MM-DD hh:mm:ss'})" name="activity_start" value="<?php echo !empty($activity['activity_start'])?$activity['activity_start']:"";?>" <?php echo input_disabled($status);?> />
                                </div>
                                <div style="margin-top: 5px;">
                                    <span class="pull-left  time-title">结束时间：</span>
                                    <input class="form-control time-input" readonly onclick="laydate({istime: true, format: 'YYYY-MM-DD hh:mm:ss'})" name="activity_end" value="<?php echo !empty($activity['activity_end'])?$activity['activity_end']:"";?>" <?php echo input_disabled($status);?> />
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="lastname" class="col-sm-2 control-label"><span class="red">*</span>参与次数</label>
                            <div class="col-sm-3">
                                <input type="number" class="form-control" id="times" name="times" min="1" placeholder="0表示不限制次数"
                                  value="<?php echo !empty($activity['total_times']) ? $activity['total_times'] : (isset($activity['day_times']) ? $activity['day_times'] : "");?>" >
                            </div>
                            <div class="col-sm-3">
                                <select class="form-control" name="times-type">
                                    <option value="1" <?php echo empty($activity['day_times']) ? "selected" : "" ?> >次/人/活动全程</option>
                                    <option value="2" <?php echo !empty($activity['day_times']) ? "selected" : "" ?> >次/人/天</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group" >
                            <label for="lastname" class="col-sm-2 control-label">背景图片</label>
                            <div class="col-sm-2">
                                <div class="login-mima-icon">
                                   <div class="checkbtn">
                                       <em class="b-text">ON</em>
                                       <em class="b-pwd">OFF</em>
                                       <em class="text-bg"></em>
                                       <em class="pwd-bg"></em>
                                   </div>
                                </div>
                            </div>
                            <div class="text-muted special_text col-sm-8">使用背景开关打开(ON)可使用图片，关闭时使用纯色</div>
                        </div>

                        <div class="form-group grout-bg-color">
                            <label for="lastname" class="col-sm-2 control-label">使用纯色</label>
                            <div class="col-sm-4 change_bg_btn">
                                <input type="color" class="bg_color" />
                            </div>
                        </div>

                        <div class="form-group grout-bg-img" style="display:none;">
                            <label class="col-sm-2 control-label" >更换背景</label>
                            <div class="col-sm-4 change_bg_btn">
                                <input type="file"  class="img" name="imgupload">
                            </div>
                            <div class="text-muted special_text col-sm-6">
                                <span class="pageWidth">700</span>*<span class="pageHeight">1360</span>像素，支持格式：jpg,jpeg,bmp,png,gif 大小不超过1M</div>
                        </div>

                        <div class="form-group">
                            <label for="lastname" class="col-sm-2 control-label"><span class="red">*</span>活动说明</label>
                            <div class="col-sm-6">
                                <textarea class="form-control" rows="6" name="desc" placeholder="活动申请说明,请控制在10000个字符以内" style="resize:none" <?php input_disabled($status);?> ><?php echo !isset($activity['desc']) ? "" : $activity['desc'];?></textarea>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-2 control-label"><span class="red">*</span>参与基数</label>
                            <div class="col-sm-6">
                                <input type="number" name="base_number" class="form-control" value="<?php echo isset($activity['base_number']) ? (int)$activity['base_number'] : 0;?>" <?php input_disabled($status);?> >
                            </div>
                            <label class="control-label text-muted">人</label>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-2 control-label"><span class="red">*</span>分享</label>
                            <div class="col-sm-8">
                                <lable>
                                    <input type="radio" name="allow_share" value="0" <?php echo !(isset($activity['allow_share']) && $activity['allow_share']==1) ? 'checked':'';?> <?php input_disabled($status);?>> 不允许
                                </lable>
                                <lable>
                                    <input type="radio" name="allow_share" value="1" <?php echo (isset($activity['allow_share']) && $activity['allow_share']==1) ? 'checked':'';?> <?php input_disabled($status);?> > 允许
                                </lable>
                                <label>可增加</label>
                                <label style="width:60px;">
                                    <input type="text" name="additional_times" class="form-control" value="<?php echo isset($activity['additional_times']) ? (int)$activity['additional_times'] : 0;?>" <?php input_disabled($status);?>>
                                </label>
                                <label>次抽奖机会</label>
                            </div>
                        </div>
                    </div>
                <!-- 活动奖品设置 -->
                    <div class="activity-reward-set"  style="display:none;width:100%">
                            <span class="red">*</span><span>抽奖模式</span>
                            <label><input type="radio" name="mode"  value="1" <?php input_disabled($status);?>
                                <?php echo isset($activity['mode']) && $activity['mode'] == 1 ? "checked": "";?> >数量控制概率</label>
                            <label><input type="radio" name="mode"  value="2" <?php input_disabled($status);?>
                                <?php echo isset($activity['mode']) && $activity['mode'] == 1 ? "": "checked";?>>纯概率控制</label>
                            <div class="mode-content" <?php echo isset($activity['mode']) && $activity['mode'] == 1 ? "" : 'style="display:none"';?> >
                                 <div class="form-group">
                                    <label for="lastname" class="col-sm-2 control-label"><span class="red">*</span>预估参与人数</label>
                                    <div class="col-sm-3">
                                        <input  type="number" class="form-control"  min="1" name="predict_people" placeholder="" <?php input_disabled($status);?> value="<?php echo !isset($activity['predict_people']) ? null : $activity['predict_people'];?>">
                                    </div><br/>
                                    <span class="text-muted">此值影响到中奖概率，不可设置为0</span>
                                </div>
                                <div class="form-group">
                                    <label for="lastname" class="col-sm-2 control-label"><span class="red">*</span>中奖限制</label>
                                    <div class="col-sm-3">
                                        <input  type="number" class="form-control"  min="0" name="win_times" placeholder="" <?php input_disabled($status);?> value="<?php echo !isset($activity['win_times']) ? null : $activity['win_times'];?>">
                                    </div><br/>
                                    <span class="text-muted">限制每一个用户最多能中奖多少次,填 0 表示不限制</span>
                                </div>
                                <div class="form-group">
                                    <label for="lastname" class="col-sm-2 control-label">中奖概率</label>
                                    <div class="col-sm-6">
                                        <span class="text-muted">中奖概率=奖品数量/预估的参与人数*100%<br/>
                                        最小可设置为0，最大可设置100%<br/>
                                    </div>
                                </div>
                            </div>
                            <br/>
                            <table class="table table-bordered" style="text-align:center;" >
                                <thead>
                                    <tr>
                                        <td width="10%">奖项</td>
                                        <td width="15%">奖品名称</td>
                                        <td width="5%">奖品数量</td>
                                        <td width="5%">概率(%)</td>
                                        <td width="15%">奖品类型</td>
                                        <td width="15%">奖品代码</td>
                                        <td width="15%">奖品面值(元)</td>
                                        <td width="5%" <?php ele_display_none($status);?> >操作</td>
                                    </tr>
                                </thead>
                                <tbody class="item-tbody">
                                <?php
                                    if(isset($activity['id']) && $activity['id'] > 0):
                                        if(!empty($activity['prize_item']) && is_array($activity['prize_item'])):
                                        foreach($activity['prize_item'] as $item):
                                ?>

                                        <tr>
                                            <td>
                                                <input type="text"  name="name[]" value="<?php echo $item['name']?>" <?php input_disabled($status);?> />
                                            </td>
                                            <td>
                                                <input type="text"  name="content[]" value="<?php echo $item['content']?>" <?php input_disabled($status);?> />
                                            </td>
                                            <td>
                                                <input type="text"  name="nums[]" value="<?php echo $item['nums']?>" />
                                            </td>
                                            <td>
                                                <input type="text"  name="chance[]" value="<?php echo $item['chance']?>" <?php input_disabled($status);?> />
                                            </td>
                                            <td>
                                                <select name="type[]" <?php input_disabled($status);?> />
                                                    <option value="1" <?php echo $item['type'] == 1 ? "selected" : ""?>>新汇生活</option>
                                                    <option value="2" <?php echo $item['type'] == 2 ? "selected" : ""?>>油码营销平台红包</option>
                                                    <option value="3" <?php echo $item['type'] == 3 ? "selected" : ""?>>油我发起红包</option>
                                                    <option value="4" <?php echo $item['type'] == 4 ? "selected" : ""?>>人工处理</option>
                                                    <option value="5" <?php echo $item['type'] == 5 ? "selected" : ""?>>不需要处理</option>
                                                </select>
                                            </td>
                                            <td>
                                                <input type="text"  name="code[]" value="<?php echo $item['code']?>" <?php input_disabled($status);?> />
                                            </td>
                                            <td>
                                                <input type="text"  name="money[]" value="<?php echo $item['money']?>" <?php input_disabled($status);?> />
                                            </td>
                                            <?php if($status < 2){?>
                                            <td style="width:5%;"  >
                                                <div class="btn btn-danger btn-xs" onclick="del_item(this)">删除</div>
                                            </td>
                                            <?php };?>
                                        </tr>

                                <?php
                                        endforeach;
                                        endif;
                                    else:
                                ?>
                                        <tr>
                                            <td><input type="text"  name="name[]" value=""></td>
                                            <td><input type="text"  name="content[]" value=""></td>
                                            <td><input type="text"  name="nums[]" value=""></td>
                                            <td><input type="text"  name="chance[]" value=""></td>
                                            <td>
                                                <select name="type[]">
                                                    <option value="1">新汇生活</option>
                                                    <option value="2">油码营销平台红包</option>
                                                    <option value="3">油我发起红包</option>
                                                    <option value="4">人工处理</option>
                                                    <option value="5">不需要处理</option>
                                                </select>
                                            </td>
                                            <td><input type="text"  name="code[]" value=""></td>
                                            <td><input type="text"  name="money[]" value=""></td>
                                            <td></td>
                                        </tr>
                                <?php endif;?>
                                </tbody>
                            </table>
                            <span class="btn btn-primary add-item" <?php ele_display_none($status);?> />添加奖项</span>
                        </div>

                        <!-- 对接设置开始 -->
                        <div class="joint" style="display:none;">
                            <div class="pay_set">
                                <input type="checkbox" name="pay_switch" class="chkbox" <?php echo (isset($activity['pay_switch']) && $activity['pay_switch']==1) ? "checked" : "" ;?>><span style="padding:2px 2px;" class="chkbox-text">支付网关设置</span>
                                <dl>
                                    <dt><span class="red">*</span>网关环境</dt>
                                    <dd>
                                        <label><input type="radio" name="gateway_env" value="1" <?php echo (isset($activity['gateway_env']) && $activity['gateway_env']==1) ? "checked" : "" ; ?> ><span>测试环境</span></label>
                                        <label><input type="radio" name="gateway_env" value="2" <?php echo !(isset($activity['gateway_env']) && $activity['gateway_env']==1) ? "checked" : "" ; ?>><span>正式环境</span></label>
                                    </dd>
                                </dl>
                                <dl>
                                    <dt><span class="red">*</span>商户名称</dt>
                                    <dd>
                                        <input type="text" name="merchant_name" value="<?php echo !empty($activity['merchant_name']) ? $activity['merchant_name'] : '' ; ?>" />
                                    </dd>
                                </dl>
                                <dl>
                                    <dt><span class="red">*</span>商户编码</dt>
                                    <dd>
                                        <input type="text" name="merchant_code" value="<?php echo !empty($activity['merchant_code']) ? $activity['merchant_code'] : "" ; ?>" >
                                    </dd>
                                </dl>
                                <dl>
                                    <dt><span class="red">*</span>账户名称</dt>
                                    <dd>
                                        <input type="text" name="account_name" value="<?php echo !empty($activity['account_name']) ? $activity['account_name'] : "" ; ?>" >
                                    </dd>
                                </dl>
                                <dl>
                                    <dt><span class="red">*</span>私钥密码</dt>
                                    <dd>
                                        <input type="text" name="secret_key" value="<?php echo !empty($activity['secret_key']) ? $activity['secret_key'] : "" ; ?>" >
                                    </dd>
                                </dl>
                                <dl>
                                    <dt><!-- <span class="red">*</span> -->上传证书</dt>
                                    <dd>
                                        <input type="hidden" name="crt_cert" class="crt_path" value="<?php echo !empty($activity['crt_cert'])?$activity['crt_cert']:'';?>" />
                                        <input type="file" name="crt" class="cert crt_cert" placeholder="crt格式" />
                                    </dd>
                                    <dd><span class="text-muted">crt格式</span></dd>
                                    <dd class="crt_info"><?php echo !empty($activity['crt_cert']) ? "<span style='color:green'>已上传</span>" : '' ; ?></dd>
                                </dl>
                                <dl>
                                    <dt><span class="red">*</span>上传证书</dt>
                                    <dd>
                                        <input type="file" name="pfx" value="" class="cert pfx_cert" placeholder="pfx格式" />
                                        <input type="hidden" name="pfx_cert" class="pfx_path" value="<?php echo !empty($activity['pfx_cert'])?$activity['pfx_cert']:'';?>" />
                                    </dd>
                                    <dd><span class="text-muted">pfx格式</span></dd>
                                    <dd class="pfx_info"><?php echo !empty($activity['pfx_cert']) ? "<span style='color:green'>已上传</span>"  : '' ; ?></dd>
                                </dl>
                            </div>

                            <div class="divider"></div>
                            <div class="hlife_set">
                                <input type="checkbox" name="hlife_switch" class="chkbox" <?php echo (isset($activity['hlife_switch']) && $activity['hlife_switch']==1) ? "checked" : "" ;?> > <span class="chkbox-text" style="margin-right:15px;">汇生活设置</span>
                                    <?php if($ticket_setting):foreach($ticket_setting as $val):?>
                                    <input type="radio" value="<?php echo $val['id'];?>" <?php echo isset($activity['ticket_id'])&&$activity['ticket_id']==$val['id'] ? "checked":'';?> name="ticket_id" > <?php echo $val['version']?>版 &nbsp;&nbsp;
                                    <?php endforeach;endif;?>
                                <!-- <dl>
                                    <dt><span class="red">*</span>发码通道</dt>
                                    <dd>
                                        <input type="text" name="channel" placeholder="请使用拼音填写活动名称" value="<?php echo !empty($activity['channel']) ? $activity['channel'] : "" ; ?>" >
                                    </dd>
                                </dl>
                                <dl>
                                    <dt><span class="red">*</span>发码密钥</dt>
                                    <dd>
                                        <input type="text" name="secret" placeholder="长度请不要超过255个" value="<?php echo !empty($activity['secretkey']) ? $activity['secretkey'] : "" ; ?>" >
                                    </dd>
                                </dl>
                                <dl>
                                    <dt>活动IP地址</dt>
                                    <dd>
                                        <span class="red"><?php echo gethostbyname(parse_url(site_url(), PHP_URL_HOST));?></span>
                                    </dd>
                                </dl> -->
                            </div>
                            <div class="divider"></div>
                            <!-- 短信设置 -->
                            <div class="hlife_set">
                                <input type="checkbox" name="text_switch" class="chkbox" <?php echo (isset($activity['text_switch']) && $activity['text_switch']==1) ? "checked" : "" ;?>> <span class="chkbox-text" style="margin-right:30px;">短信设置</span>
                                <?php if($text_setting):foreach($text_setting as $val):?>
                                <input type="radio" value="<?php echo $val['id']?>" name="text_id" <?php echo isset($activity['ticket_id'])&&$activity['text_id']==$val['id'] ? "checked":'';?> > <?php echo $val['api_desc']?> &nbsp;&nbsp;
                                <?php endforeach;endif;?>
                                <div style="margin-left:104px;margin-top:10px;">
                                    <span>短信内容</span>
                                    <select name="text_tpl_id">
                                        <option value="">请选择想要使用的短信模板</option>
                                        <?php if($text_tpls):?>
                                            <?php
                                                foreach($text_tpls as $v)
                                                {
                                                    $selected = isset($activity['text_tpl_id'])&&$activity['text_tpl_id']==$v['id']?'selected':'';
                                                    echo "<option value='{$v['id']}' {$selected}>{$v['content']}</option>";
                                                }
                                            ?>
                                        <?php endif;?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <!-- 对接设置结束 -->
                        <div class="form-group uploadImg" style="margin:30px 0px 0px;">
                            <div class="operateBtn">
                                <span class="btn btn-primary activity-submit" >保存</span>
                                <span class="btn btn-default activity-cancel" style="margin-left:10%;">取消</span>
                            </div>
                         </div>
                </form>
            </div>
            <!-- 活动设置结束 -->
        <div class="changes_all" style="display: none;padding:10px;">
            <div class="go_activity_set">返回活动设置</div>
            <!--更换图片-->
            <div class="changeImg clearfix">
                <div class="change_title">更换图片</div>
                <div class="change_content">
                    <form  action="<?echo site_url('template/save/type/card');?>" class="form-horizontal group-border-dashed" method="post" id="imgForm" enctype="multipart/form-data" target="rfFrame">
                        <!-- <input type="hidden" value="<?php echo isset($template['id']) ? $template['id'] : '0';?>" name="id"> -->
                        <input type="hidden" value="<?php echo $template['temp_path']?>" name="temp_path">
                        <!-- <input type="hidden" value="<?php echo  '$activity_id';?>" name="activity_id"> -->
                        <div class="form-group uploadImg">
                             <div class="col-sm-2">
                                 <!-- <div id="uploaderInput" class="dz-default dz-message uploader_box"></div> -->
                               <input type="file" class="img" name="imgupload" value="ajaxFileUpload">
                            </div>
                         </div>
                        <input type="hidden" name="template_content" value="" id="template_content">
                    </form>
                    <div class="change_explain">
                        <span class="img_pixel">150*120</span>像素，支持<span class="img_format">JPG,JPEG,TIFF,PNG,GIF,BMP</span>格式，小于<span class="img_size">200</span>KB
                    </div>
                </div>
            </div>
                <!--图片位置-->
                <div class="imgLocation clearfix">
                    <div class="change_title">图片位置</div>
                    <div class="change_content">
                        拖动到自定义的位置： 距离顶部： <i class="relative_top">0%</i>,距离左侧： <i class="relative_left">0%</i>
                    </div>
                </div>
                <!--图片层级-->
                <div class="img_level clearfix">
                    <div class="change_title">图片层级</div>
                    <div class="change_content">
                        <input type="text" class="level_input" id="level_input" />
                        <div class="level_rules">
                            1至999数字，数字越大层级越高
                        </div>
                    </div>
                </div>
        </div>
    </div>  <!-- 模板设置结束-->
    <!-- <iframe id="rfFrame" name="rfFrame" src="about:blank" style="display:none;"></iframe>  -->
</div>

<script src="js/jquery-2.1.1.min.js"></script>
<script language="javascript" type="text/javascript" src="js/layer-v3.0.3/layer.js"></script>
<script src="js/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="<?php echo $template_dir;?>libs/js/edit_template.js"></script>
<script src="js/laydate/laydate.js"></script>
<script type="text/javascript" src="js/jquery.ajaxfileupload.js"></script>

<script>
var global = global || {};
global.baseUrl = '//';
global._target = null;


$(function () {
    laydate.skin("molv");
    // switch控制背景隐藏与现实
    $(".checkbtn").on("click",function(){
        console.log($(".pwd-bg").css("display"));
        if( $(".pwd-bg").css("display") == "none"){ //隐藏背景图片
            $(".background-switch").html(0);
        } else { //显示背景图片
            $(".background-switch").html(1);

            var parWidth = $("#activityPage")[0].clientWidth * 2,
                parHeight = $("#activityPage")[0].clientHeight * 2;

            $(".pageWidth").html(parWidth);
            $(".pageHeight").html(parHeight);
        }
    })
    // 自定义按钮的动画
    $(".text-bg").on("click",function(){
        $("#mima").attr('type', 'text');
        $(".text-bg").css("display","none");
        $(".pwd-bg").css("display","block");
        $(".checkbtn").css("background","#4D90FD");
        $(".b-pwd").hide();
        $(".grout-bg-img").show();
        $(".grout-bg-color").hide();
        $(".b-text").show();
    })
    $(".pwd-bg").on("click",function(){
        $("#mima").attr('type', 'password');
        $(".text-bg").css("display","block");
        $(".pwd-bg").css("display","none");
        $(".checkbtn").css("background","#e3e3e3");
        $(".b-pwd").show();
        $(".grout-bg-img").hide();
        $(".grout-bg-color").show();
    });

    /**
     *活动内容/奖品设置 tab切换
     */
    $(".activity-nav>li").click(function(){
        if($(this).attr("idx") == "1")
        {
            $(".activity-content-set").css("display", "block");
            $(".flag").val(1);
            $(".activity-reward-set").css("display", "none");
            $(".joint").css("display", "none");

        }
        else if($(this).attr("idx") == "2")
        {
            $(".activity-content-set").css("display", "none");
            $(".flag").val(2);
            $(".activity-reward-set").css("display", "block");
            $(".joint").css("display", "none");
        }
        else if($(this).attr("idx") == "3")
        {
            $(".activity-content-set").css("display", "none");
            $(".flag").val(3);
            $(".activity-reward-set").css("display", "none");
            $(".joint").css("display", "block");
        }
        $(this).addClass("cur").siblings().removeClass("cur");

    })
    /**
     *检查活动名称是否重复
     */
    $(".activity_name").blur(function(){
        var name = $(this).val();
        res1 = no_empty(name, '活动名称');
        if(res1.err_code){
            layer.alert(res1.msg, {icon:2});
            return false;
        }

        var activity_id = $(".activity_id").val();
        $.ajax({
            url: "<?php echo site_url('_'.SUITENAME.'/activity/check_activity_name');?>",
            type: "post",
            data: {name:name, ac_id:activity_id},
            dataType: 'json',
            success: function(obj){
                if(obj.err_code){
                    $(".name_info").html(obj.msg).css('color', 'red');
                    //layer.msg(obj.msg, {icon:2, time:2000});
                } else {
                    $(".name_info").html("");
                    //layer.msg(obj.msg, {icon:1})
                }
            }
        })
    })


    /**
     *增加奖项
     */
    $(".add-item").click(function(){
        var item = '<tr><td><input type="text"  name="name[]" value=""></td><td><input type="text"  name="content[]" value=""></td>'
                    +'<td><input type="text"  name="nums[]" value=""></td><td><input type="text"  name="chance[]" value=""></td>'
                    +'<td><select name="type[]"><option value="1">新汇生活</option><option value="2">油码营销平台红包</option>'
                    +'<option value="3">油我发起红包</option><option value="4">人工处理</option><option value="5">不需要处理</option></select></td>'
                    +'<td><input type="text"  name="code[]" value=""></td><td><input type="text"  name="money[]" value=""></td>'
                    +'<td style="width:5%;"><div class="btn btn-danger btn-xs" onclick="del_item(this)">删除</div></td></tr>';
        if( $('.item-tbody>tr').length<4)
            $(".item-tbody").append(item);
        else
            alert('最多添加4个奖项！');
    });



    /**
     *中奖概率计算方式切换
     */

    $(":radio[name='mode']").click(function(){
        if($(this).val() == "1")
        {
            $(".mode-content").css("display", "block");
        }
        else if($(this).val() == "2")
        {
            $(".mode-content").css("display", "none");
        }
    });
    // 点击取消返回列表页
    $(".activity-cancel").on("click",function(){
        parent.to_list();
    });



    /**
     *提交设置内容
     */
    $(".activity-submit").click(function(){
        // if($(".status").val() >= "3"){
        //     layer.msg("活动已发布，不能修改活动数据",{icon:2, time:3000});
        //     return false;
        // }

        var flag = $(".flag").val();

        //不能直接就去设置奖品，先设置活动信息
        var id = $(".activity_id").val();
        if( flag > 1 && id <= "0")
        {
            layer.alert("请先填写并保存活动内容设置信息", {icon: 0, time: 2000});
            return false;
        }

        //活动内容设置
        if(flag == "1")
        {
            if($("input[name='activity_name']").val() == '')
            {
                layer.alert('活动名称不能为空', {icon:2});
                return false;
            }
            //活动时间
            var start = $("input[name='activity_start']").val();
            var end = $("input[name='activity_end']").val();
            if( start =='' ||  end =='')
            {
                layer.alert('请选择活动起始和结束时间', {icon:2});
                return false;
            }
            if( start !='' && end !='' && start >= end)
            {
                layer.alert('活动起始时间必须小于结束时间', {icon:2});
                return false;
            }
            //活动次数
            var times = $("input[name='times']").val();
            if( times < 0 )
            {
                layer.alert('参与次数必须大于等于0', {icon:2});
                return false;
            }
            //活动说明
            var desc = $("textarea[name='desc']").val();
            res1 = no_empty(desc, '活动说明');
            if(res1.err_code){
                layer.alert(res1.msg, {icon:2});
                return false;
            }
            if(desc.length > "10000")
            {
                layer.alert('活动申请说明请控制在10000字符内', {icon:2});
                return false;
            }
            // 参与人数基数
            var base_number = $("input[name=base_number]").val();
            if(/^\d+$/.test(base_number) == false){
                layer.alert('活动基数请填写大于等于0的正数',{icon: 2});
                return false;
            }
            // 分享后增加的抽奖次数
            var allow_share = $("input[name=allow_share]:checked").val();
            if(allow_share == "1"){
                var additional_times = $("input[name=additional_times]").val();
                if(/^\d+$/.test(additional_times) == false){
                    layer.alert('允许分享后，可增加的次数请填写大于等于0的正数',{icon: 2});
                    return false;
                }
            }
        }
        //奖品设置
        else if(flag == "2")
        {
            var nameObj = $("input[name='name[]']");
            var contentObj = $("input[name='content[]']");//奖品
            var numObj = $("input[name='nums[]']");
            var chanceObj = $("input[name='chance[]']");
            var typeObj = $("select[name='type[]'] :selected");//类型
            var codeObj = $("input[name='code[]']");//代码
            var moneyObj = $("input[name='money[]']");

            var mode = $(":radio[name='mode']:checked").val();
            var digit_patt = /^\d*$/;//整数
            var positive_digit = /^[1-9]\d*$/;//正整数


            //数量概率控制
            if(mode == "1")
            {
                var predict_people = $("input[name='predict_people']").val();
                if(positive_digit.test(predict_people))
                {}
                else
                {
                    layer.alert('选择[数量控制概率]模式时，[预估人数]请填写整数，不能小于1', {icon:2});
                    return false;
                }

                var win_times = $("input[name='win_times']").val();
                if(digit_patt.test(win_times))
                {}
                else
                {
                    layer.alert('选择[数量控制概率]模式时，[中奖限制]次数请填写大于0的整数', {icon:2});
                    return false;
                }
            }
            //纯概率控制
            else if(mode == "2")
            {}

            //验证奖项信息  奖项必填、奖品名称必填；数量和面值、代码与类型有关
            var next = true;
            var total_num = 0;
            nameObj.each(function(i){

                if($(this).val() == '')
                {
                    layer.alert('[奖项]必须填写', {icon:2, time:2000});
                    next = false;
                    return false;
                }
                if(contentObj.eq(i).val() == '')
                {
                    layer.alert('[奖品名称]必须填写', {icon:2});
                    next = false;
                    return false;
                }

                //非【必须要发送】类型 奖品代码必填，面值大于0
                if(typeObj.eq(i).val() <  "5")
                {
                    if(!digit_patt.test(numObj.eq(i).val()))
                    {
                        layer.alert('[数量]请填写整数', {icon:2});
                        next = false;
                        return false;
                    }
                    else
                    {
                        total_num = total_num + parseInt(numObj.eq(i).val());
                    }

                    if(codeObj.eq(i).val() == '')
                    {
                        layer.alert('非[不需要发送]的类型时，请填写[奖品代码]', {icon:2});
                        next = false;
                        return false;
                    }
                    if(!positive_digit.test(moneyObj.eq(i).val()))
                    {
                        layer.alert('非[不需要发送]的类型时，[面值]请填写大于0的整数', {icon:2});
                        next = false;
                        return false;
                    }

                }
                else
                {}
                //纯概率控制时，概率必填
                if(mode == "2")
                {

                    if(!digit_patt.test(chanceObj.eq(i).val()))
                    {
                        layer.alert('[概率]请填写整数', {icon:2, time:2000});
                        next = false;
                        return false;
                    }

                }
            });
//          layer.msg(next,{icon:2,time:1000});
//          return false;
            if(next === false)
                return false;
            /*if(mode == "1")
            {
                if(total_num > parseInt(predict_people))
                {
                    layer.alert('所有奖品概率总和不能大于100%，请修改', {icon: 2, time: 2000});
                    return false;
                }
            }
            else if(mode == "2")
            {
                var total_chance = 0;
                chanceObj.each(function(i){
                    total_chance += parseInt(chanceObj.eq(i).val());
                });
                if(total_chance > 100)
                {
                    layer.alert('所有奖品概率总和不能大于100%，请修改', {icon: 2, time: 2000});
                    return false;
                }
            }*/
        }
        else if(flag == "3")
        {

            var pay_switch = $(":checkbox[name='pay_switch']").prop("checked");
            var gateway_env = $(':radio[name="gateway_env"]:checked').val();
            var merchant_name = $('input[name="merchant_name"]').val();
            var merchant_code = $('input[name="merchant_code"]').val();
            var account_name = $('input[name="account_name"]').val();
            var secret_key = $('input[name="secret_key"]').val();
            var crt_path = $('input[name="crt_cert"]').val() ? $('input[name="crt_cert"]').val() : '';
            var pfx_path = $('input[name="pfx_cert"]').val();
            if(pay_switch)
            {
                res1 = no_empty(merchant_name, '商户名称');
                if(res1.err_code){
                    layer.alert(res1.msg, {icon:2});
                    return false;
                }

                res2 = no_empty(merchant_code, '商户编码');
                if(res2.err_code){
                    layer.alert(res2.msg, {icon:2});
                    return false;
                }

                res3 = no_empty(account_name, '账户名称');
                if(res3.err_code){
                    layer.alert(res3.msg, {icon:2});
                    return false;
                }

                res4 = no_empty(secret_key, '私钥密码');
                if(res4.err_code){
                    layer.alert(res4.msg, {icon:2});
                    return false;
                }
                /*if($.inArray($(".crt_info>span").text(),["已上传", "上传成功"]) == "-1")
                {
                    res5 = no_empty(crt_path, 'crt证书');
                    if(res5.err_code){
                        layer.alert(res5.msg, {icon:2});
                        return false;
                    }
                }*/

                if($.inArray($(".pfx_info>span").text(),["已上传", "上传成功"]) == "-1" )
                {
                    res6 = no_empty(pfx_path, 'pfx证书');
                    if(res6.err_code){
                        layer.alert(res6.msg, {icon:2});
                        return false;
                    }
                }

            }


            var hlife_switch = $("input[name='hlife_switch']").prop("checked");
            if(hlife_switch)
            {
                var ticket_id = $("input[name=ticket_id]:checked").val();
                if(ticket_id== undefined || ticket_id <= 0){
                    layer.alert('勾选汇生活设置后，请选择发码接口版本', {icon:2});
                    return false;
                }
                // 发码通道
                /*var channel = $('input[name="channel"]').val();
                res7 = no_empty(channel, '发码通道');
                if(res7.err_code){
                    layer.alert(res7.msg, {icon:2});
                    return false;
                }
                if(channel.length > "96"){
                    layer.alert("发码通道长度不能超过96位，请修改", {icon:2});
                    return false;
                }*/
                // 发码密钥
                /*var secret = $('input[name="secret"]').val();
                res7 = no_empty(secret, '发码密钥');
                if(res7.err_code){
                    layer.alert(res7.msg, {icon:2});
                    return false;
                }
                if(secret.length > "255"){
                    layer.alert("发码密钥长度不能超过255位，请修改", {icon:2});
                    return false;
                }*/
            }
            // 短信配置
            var text_switch = $("input[name='text_switch']").prop("checked");
            if(text_switch)
            {
                var text_id = $("input[name=text_id]:checked").val();
                if( text_id == undefined || text_id <= 0){
                    layer.alert('勾选短信设置后，请选择发送短信的通道', {icon:2});
                    return false;
                }
                var text_tpl_id = $("select[name=text_tpl_id] option:selected").val();
                if(text_tpl_id == undefined || text_tpl_id <= 0){
                    layer.alert('勾选短信设置后，请选择发送的短信内容模板', {icon:2});
                    return false;
                }
            }
        }
        var template_html = $("#activity_template").html();
        $("#template_content").val(template_html);

        $.ajax({
            type: "POST",
            url: "<?php echo site_url('_'.SUITENAME.'/activity/save_lottery/');?>",
            data: $("#form-content").serialize(),
            dataType: 'json',
            success: function(data){
                //成功
                if(data.err_code == 0)
                {
                    //保存活动内容成功
                    if(flag == "1")
                    {
                        //新增成功后，去设置奖品
                        if(id == "0")
                        {
                            $(".activity_id").val(data.id);
                            $(".flag").val(2);
                            $(".activity-nav>li").removeClass("cur").eq(1).addClass("cur");
                            $(".activity-content-set").css("display", "none");
                            $(".activity-reward-set").css("display", "block");
                            $(".template_id").val(0);
                        }
                        else
                        {
                            layer.confirm('保存成功', {
                              icon: 1,
                              btn: ['编辑模板','活动列表'] //按钮
                            }, function(){
                                layer.close(layer.index);
                            }, function(){
                                parent.to_list();
                              //window.location.href="<?php echo site_url('_'.SUITENAME.'/activity/activity_list');?>";
                            });
                        }

                    }
                    else if(flag == "2")
                    {
                        $(".flag").val(3);
                        $(".activity-nav>li").removeClass("cur").eq(2).addClass("cur");
                        $(".activity-content-set").css("display", "none");
                        $(".activity-reward-set").css("display", "none");
                        $(".joint").css("display", "block");
                    }
                    //保存奖品信息成功
                    else
                    {
                        layer.confirm('保存成功', {
                          icon: 1,
                          btn: ['编辑模板','活动列表'] //按钮
                        }, function(){
                            layer.close(layer.index);
                        }, function(){
                            parent.to_list();
                          //window.location.href="<?php echo site_url('_'.SUITENAME.'/activity/activity_list');?>";
                        });
                    }

                }
                //保存失败
                else
                {
                    layer.alert('保存失败，'+data.msg, {icon:2, time:2000});
                }
            }

        });
    })
});


// 非空验证
function no_empty(_var,varname)
{
    var empty_patt = /^\s*$/;
    var info1 = info2 = '';
    if(varname == "crt证书" || varname == "pfx证书"){
        info1 = info = '必须上传';
    } else {
        info1 = '必须填写';
        info = '不能全为空格';
    }
    if (_var == "" || _var == undefined) {
        return {'err_code': 1, 'msg': varname+info1};
    }
    if(_var.length==0)
        return {'err_code': 1, 'msg': varname+info1};
    if(empty_patt.test(_var))
        return {'err_code': 1, 'msg': varname+info2};
    return {'err_code': 0, 'msg': varname+'验证通过'};
}

//删除奖项
function del_item(obj)
{
    $(obj).parents('tr').remove();
}

var global = global || {};
global.baseUrl = '/admin/templates/default/activity_temp/'+"baseurl"+'/';

/**
 * 保存模板信息
 */
$(document).ready(function(){
    $(".save_setting_btn").click(function(){

        var template_html = $("#activity_template").html();
        var id=$(".activity_id").val();
        if( id<= 0 )
        {
          layer.msg('请先创建活动，再设置模板信息',{icon:2, time:2000});
          return false;
        }
        //发送给服务器保存
        $.ajax({
            type:"post",
            url:"<?php echo site_url('_'.SUITENAME.'/activity/save_template');?>",
            async:true,
            data:{id: id, template_content: template_html},
            dataType:'json',
            success:function(data){
                if(data.err_code)
                {
                    layer.msg(data.msg,{icon:2,time:2000});
                }
                else
                {
                    layer.confirm('保存成功',{
                        icon:1,
                        btn:['继续编辑', '活动列表'],
                      },function(){
                        layer.close(layer.index);
                      },function(){
                        parent.to_list();
                      })
                }
            }
        });
    });
})


$(function(){
    /**
     *图片上传
     */
    $(".img").ajaxfileupload({
        action: "<?php echo site_url('_'.SUITENAME.'/activity/change_template_pics');?>",
        valid_extensions : ['jpg','jpeg','png'],
        params: {
           activity_id: activity_id = $(".activity_id").val(),
           field: 'imgupload',
        },
        onComplete: function(response) {
            //console.dir(response);
            if(response.err_code == "0")
            {
                if(global._target.attr("src")){
                    global._target.attr("src","<?php echo base_url();?>"  + response.url);
                }else{
                    global._target.css("background","url("+"<?php echo base_url();?>" + response.url+") center center no-repeat");
                }
            }
            else
            {
                if(response && response.msg){
                    layer.msg(response.msg,{icon:2});
                } else {
                    layer.msg('图片大小超过服务器限制，请更换图片！',{icon:2});
                }
            }
          //alert(JSON.stringify(response));
        },
        onStart: function() {
            activity_id = $(".activity_id").val();
        },
        onCancel: function() {
          console.log('no file selected');
        },
    });

    /**
     *crt证书上传
     */

    $(".crt_cert").ajaxfileupload({
        action: "<?php echo site_url('_'.SUITENAME.'/activity/upload_cert');?>",
        valid_extensions : ['crt'],
        params: {
           cert_type: "1",
           ac_id: $(".activity_id").val(),
           field: 'crt'
        },
        onComplete: function(response) {
            console.dir(response);
            if(typeof response.status != 'undefined')
            {
                layer.alert("请检查文件类型", {icon:2, time:2000});
            }
            else
            {
                if(response.err_code == "0")
                {
                     // <input type="hidden" name="crt_cert" class="crt_path">
                    // $(".crt_path").val(response.data);
                    // layer.alert(response.data);
                    $(".crt_info").html("<span style='color:green'>上传成功</span>");
                    $(".crt_path").val(response.data);
                }
                else
                {
                    layer.alert("上传失败，请检查文件类型", {icon:2, time:2000});
                }
            }

          //alert(JSON.stringify(response));
        },
    });

    /**
     *pfx证书上传
     */
// <input type="hidden" name="pfx_cert" class="pfx_path">
    $(".pfx_cert").ajaxfileupload({
        action: "<?php echo site_url('_'.SUITENAME.'/activity/upload_cert');?>",
        valid_extensions : ['pfx'],
        params: {
           cert_type: "2",
           ac_id: $(".activity_id").val(),
           field: 'pfx'
        },
        onComplete: function(response) {
            console.dir(response);
            if(typeof response.status =='undefined'){
                if(response.err_code == "0")
                {
                    // if(global._target.attr("src")){
                    //     global._target.attr("src","<?php echo base_url();?>"  + response.url);
                    // }else{
                    //     global._target.css("background","url("+"<?php echo base_url();?>" + response.url+") center center no-repeat");
                    // }
                    $(".pfx_path").val(response.data);
                    $(".pfx_info").html("<span style='color:green'>上传成功</span>");
                }
                else
                {
                    layer.alert("请检查文件类型", {icon:2, time:2000});
                }
            } else {
                layer.alert("请检查文件类型", {icon:2, time:2000});
            }

          //alert(JSON.stringify(response));
        },
    });


});



  // 点击返回活动设置
  $(".go_activity_set").on("click",function(){
    $(".activity-set").css("display","block");
    $(".changes_all").css("display","none");
  })




</script>

