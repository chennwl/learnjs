<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<style type="text/css">
		.cl-sidebar{display: block;}
		@media (min-width: 768px) and (max-width: 1220px){
			  .navbar-default .navbar-brand {
			    background-position: 0 11px;
			    height: 50px;
			    width: 45px;
			    padding-left: 35px;
			  }
			  .navbar-default .navbar-brand span {
			    display: none;
			  }
			  .cl-sidebar {
			    width: 55px;
			  }
			  #pcont {
			    margin-left: 55px;
			  }
			  #cl-wrapper.fixed-menu .menu-space {
			    width: 55px;
			  }
			  .cl-vnavigation li {
			    position: relative;
			  }
			  .cl-vnavigation .parent a {
			    background: none !important;
			  }
			  .cl-vnavigation li a i {
			    margin: 0;
			    font-size: 17px;
			  }
			  .cl-vnavigation li a span {
			    opacity: 0;
			    width: 0;
			    height: 0;
			  }
			  .cl-sidebar .side-user {
			    display: none;
			  }
			  .cl-sidebar .cl-vnavigation {
			    display: block !important;
			  }
			  .cl-vnavigation li ul {
			    display: none;
			  }
			  .cl-sidebar .collapse-button {
			    display: none;
			  }
			  .cl-sidebar .collapse-button .search {
			    display: none;
			  }
		}
		@media (min-width: 1220px){
			.cl-sidebar{display: table-cell;}
		}
		table tr td{text-align: center;vertical-align: middle;}
		@media (min-width: 767px) and (max-width: 1220px){
			#pcont{display: block;position: relative;top: -48px;}
		}
	</style>
</head>
<body>
<div class="container-fluid" id="pcont">
	<div class="page-head">
		<button class="btn btn-success btn-lg pull-right" style="margin-top:10px;" id="to_list">活动列表</button>
		<h2>活动编辑</h2>
		<ol class="breadcrumb">
			<li><a href="<?php echo site_url('_'.SUITENAME."/home");?>">首页</a></li>
			<li><a href="<?php echo site_url('_'.SUITENAME."/activity/activity_list");?>">活动管理</a></li>
			<li class="active">活动编辑</li>
		</ol>
	</div>
	<div class="cl-mcont">
		<div class="row">
			<div class="col-md-12">
				<div class="block-flat">
<!-- 					<div class="header"> -->
<!-- 						<h3>模板编辑</h3> -->
<!-- 					</div> -->
                	<!--  <IFRAME src="<?php echo $base_href?>set.php"  frameBorder=0 width="100%" height="670px" id="myframe"></IFRAME>
                    -->
                    <IFRAME src="<?php echo site_url('_'.SUITENAME.'/template/load_iframe/template_id').'/'.$template['id'].'/aid/'.$activity['id'];?>"  frameBorder=0 width="100%" height="670px" id="myframe"></IFRAME>
		
				</div>
			</div>
		</div>
	</div>
</div>
<script>
	//跳转到活动列表
	$(function(){
		$("#to_list").click(function(){
			window.location.href="<?php echo site_url('_'.SUITENAME.'/activity/activity_list');?>";
		});
	})
	
	//跳转到活动列表
	function show_modal_info(data){
		if(data > 0){
			$('#md-icon').attr('class', 'fa fa-check');
            $('#messgetitle').html("保存成功!");
            $('#messagecontent').html('');
            $('#md-slideUp').niftyModal("show");
            $('.md-close').click(function(){
              //window.location = history.go(-1);
              location.href = "<?php echo site_url('_'.SUITENAME.'/activity/activity_list')?>";
            });
		} else {
			$('#md-icon').attr('class', 'fa fa-times');
            $('#messgetitle').html("保存失败!");
            $('#md-slideUp').niftyModal("show");
		}
	}
	function to_list()
	{
		window.location.href="<?php echo site_url('_'.SUITENAME.'/activity/activity_list')?>";
	}
	/*自适应js,仅适用于活动编辑页*/
	var tool = $("<div id='sub-menu-nav' style='position:fixed;z-index:9999;'></div>");
	        
	function showMenu(_this, e){
	  if(($("#cl-wrapper").hasClass("sb-collapsed") || ($(window).width() > 755 && $(window).width() < 1220)) && $("ul",_this).length > 0){   
	    $(_this).removeClass("ocult");
	    var menu = $("ul",_this);
	    if(!$(".dropdown-header",_this).length){
	      var head = '<li class="dropdown-header">' +  $(_this).children().html()  + "</li>" ;
	      menu.prepend(head);
	    }
	    
	    tool.appendTo("body");
	    var top = ($(_this).offset().top + 8) - $(window).scrollTop();
	    var left = $(_this).width();
	    
	    tool.css({
	      'top': top,
	      'left': left + 8
	    });
	    tool.html('<ul class="sub-menu">' + menu.html() + '</ul>');
	    tool.show();
	    
	    menu.css('top', top);
	  }else{
	    tool.hide();
	  }
	}

	$(".cl-vnavigation li").hover(function(e){
	  showMenu(this, e);
	},function(e){
	  tool.removeClass("over");
	  setTimeout(function(){
	    if(!tool.hasClass("over") && !$(".cl-vnavigation li:hover").length > 0){
	      tool.hide();
	    }
	  },500);
	});

	tool.hover(function(e){
	  $(this).addClass("over");
	},function(){
	  $(this).removeClass("over");
	  tool.fadeOut("fast");
	});


	$(document).click(function(){
	  tool.hide();
	});
	$(document).on('touchstart click', function(e){
	  tool.fadeOut("fast");
	});

	tool.click(function(e){
	  e.stopPropagation();
	});

	$(".cl-vnavigation li").click(function(e){
	  if((($("#cl-wrapper").hasClass("sb-collapsed") || ($(window).width() > 755 && $(window).width() < 1220)) && $("ul",this).length > 0) && !($(window).width() < 755)){
	    showMenu(this, e);
	    e.stopPropagation();
	  }
	});
</script>
</body>

</html>